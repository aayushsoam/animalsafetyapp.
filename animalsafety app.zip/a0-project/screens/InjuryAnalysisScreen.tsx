import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

export default function InjuryAnalysisScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState('symptoms');
  const [animalType, setAnimalType] = useState('dog');
  const [symptoms, setSymptoms] = useState('');
  const [analysisResult, setAnalysisResult] = useState(null);

  const animals = [
    { id: 'dog', name: 'Dog', icon: 'dog' },
    { id: 'cat', name: 'Cat', icon: 'cat' },
    { id: 'bird', name: 'Bird', icon: 'bird' },
    { id: 'rabbit', name: 'Rabbit', icon: 'rabbit' },
    { id: 'horse', name: 'Horse', icon: 'horse' },
  ];  const analyzeInjury = () => {
    // Simulate AI analysis for textual symptoms
    setAnalysisResult({
      condition: 'Suspected Sprained Leg',
      severity: 'Moderate',
      description: 'Based on the symptoms, your pet may have a sprained leg. This is a common injury that occurs when ligaments are stretched or torn.',
      recommendations: [
        'Rest: Limit movement and exercise',
        'Ice: Apply cold compress for 15-20 minutes',
        'Compression: Use a soft bandage if possible',
        'Elevation: Keep the limb elevated when resting',
      ],
      medications: [
        { name: 'Carprofen', dosage: 'As prescribed by vet', purpose: 'Pain relief and inflammation' },
        { name: 'Meloxicam', dosage: 'As prescribed by vet', purpose: 'Anti-inflammatory' },
      ],
      urgency: 'Consult a veterinarian within 24-48 hours if no improvement is seen'
    });
  };      const analyzeImage = async () => {
        try {
          // Convert your image into base64 if not already
          // For demo, we'll use a sample base64 encoded placeholder
          const imageData = "sample_base64_encoded_data"; // Replace with your actual base64 data

          const payload = {
            messages: [
              {
                role: "system",
                content: "You are a helpful assistant that describes images in details."
              },
              {
                role: "user",
                content: [
                  { text: "What's in this image?", type: "text" },
                  { image_url: { url: `data:image/jpeg;base64,${imageData}`, detail: "low" }, type: "image_url" }
                ]
              }
            ],
            model: "gpt-4o"
          };

          const response = await fetch("https://models.inference.ai.azure.com/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer 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"
            },
            body: JSON.stringify(payload)
          });

          if (!response.ok) {
            console.error(`Error fetching AI analysis. Status: ${response.status}`);
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const data = await response.json();
          console.log("AI Analysis Response:", data);

          // Use the returned completion text to update the analysis result
          setAnalysisResult({
            condition: "Injury Analysis via Image",
            severity: "Moderate",
            description: data.completion || "The AI analysis indicates a moderate injury. Please consult a vet for precise evaluation.",
            recommendations: [
              "Ensure the animal is not in further danger",
              "Keep the affected area clean",
              "Provide comfort until professional help arrives"
            ],
            medications: [
              { name: "ExampleMed", dosage: "Use as instructed", purpose: "To ease pain" }
            ],
            urgency: "Seek immediate veterinary consultation if condition worsens"
          });
        } catch (error) {
          console.error("Error analyzing image:", error);
          setAnalysisResult({
            condition: "Image Analysis Failed",
            severity: "Unknown",
            description: "Failed to analyze the image. Please try again or consult a veterinarian directly.",
            recommendations: [],
            medications: [],
            urgency: ""
          });
        }
      };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1d3557" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Injury Analysis</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'symptoms' && styles.activeTab]}
          onPress={() => setActiveTab('symptoms')}
        >
          <Text style={[styles.tabText, activeTab === 'symptoms' && styles.activeTabText]}>
            Symptoms
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'upload' && styles.activeTab]}
          onPress={() => setActiveTab('upload')}
        >
          <Text style={[styles.tabText, activeTab === 'upload' && styles.activeTabText]}>
            Upload Photo
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {!analysisResult ? (
          <>
            <Text style={styles.sectionTitle}>Select Animal Type</Text>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              style={styles.animalTypeContainer}
              contentContainerStyle={styles.animalTypeContent}
            >
              {animals.map(animal => (
                <TouchableOpacity 
                  key={animal.id}
                  style={[
                    styles.animalTypeButton,
                    animalType === animal.id && styles.selectedAnimalType
                  ]}
                  onPress={() => setAnimalType(animal.id)}
                >
                  <MaterialCommunityIcons 
                    name={animal.icon} 
                    size={28} 
                    color={animalType === animal.id ? '#ffffff' : '#1d3557'} 
                  />
                  <Text 
                    style={[
                      styles.animalTypeName,
                      animalType === animal.id && styles.selectedAnimalTypeName
                    ]}
                  >
                    {animal.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {activeTab === 'symptoms' ? (
              <View style={styles.symptomsContainer}>
                <Text style={styles.sectionTitle}>Describe the Symptoms</Text>
                <TextInput
                  style={styles.symptomsInput}
                  multiline
                  numberOfLines={6}
                  placeholder="Describe what you observe (e.g., limping, bleeding, swelling, etc.)"
                  placeholderTextColor="#adb5bd"
                  value={symptoms}
                  onChangeText={setSymptoms}
                />
                
                <Text style={styles.tipsTitle}>Tips for Description:</Text>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Mention when symptoms started</Text>
                </View>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Note any changes in behavior</Text>
                </View>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Describe the appearance of injuries</Text>
                </View>
              </View>
            ) : (
              <View style={styles.uploadContainer}>
                <View style={styles.uploadBox}>
                  <Ionicons name="cloud-upload-outline" size={48} color="#3a86ff" />
                  <Text style={styles.uploadText}>Upload a clear photo of the injury</Text>
                  <TouchableOpacity style={styles.uploadButton}>
                    <Text style={styles.uploadButtonText}>Select Photo</Text>
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.tipsTitle}>Photo Tips:</Text>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Ensure good lighting</Text>
                </View>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Get close to the injury</Text>
                </View>
                <View style={styles.tipItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.tipText}>Take multiple angles if possible</Text>
                </View>
              </View>
            )}            {activeTab === 'symptoms' ? (
              <TouchableOpacity 
                style={[
                  styles.analyzeButton,
                  (!symptoms) && styles.disabledButton
                ]}
                onPress={analyzeInjury}
                disabled={!symptoms}
              >
                <Text style={styles.analyzeButtonText}>Analyze</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity 
                style={styles.analyzeButton}
                onPress={analyzeImage}
              >
                <Text style={styles.analyzeButtonText}>Analyze Photo</Text>
              </TouchableOpacity>
            )}
          </>
        ) : (
          <View style={styles.resultContainer}>
            <View style={styles.resultHeader}>
              <View>
                <Text style={styles.resultTitle}>{analysisResult.condition}</Text>
                <View style={styles.severityBadge}>
                  <Text style={styles.severityText}>{analysisResult.severity} Severity</Text>
                </View>
              </View>
              <Image 
                source={{ uri: `https://api.a0.dev/assets/image?text=${animalType}%20with%20sprained%20leg&aspect=1:1&seed=42` }} 
                style={styles.resultImage} 
              />
            </View>
            
            <Text style={styles.resultDescription}>{analysisResult.description}</Text>
            
            <Text style={styles.recommendationsTitle}>Recommended Care:</Text>
            {analysisResult.recommendations.map((rec, index) => (
              <View key={index} style={styles.recommendationItem}>
                <View style={styles.recommendationBullet} />
                <Text style={styles.recommendationText}>{rec}</Text>
              </View>
            ))}
            
            <Text style={styles.recommendationsTitle}>Possible Medications:</Text>
            {analysisResult.medications.map((med, index) => (
              <View key={index} style={styles.medicationItem}>
                <Text style={styles.medicationName}>{med.name}</Text>
                <Text style={styles.medicationDetails}>
                  <Text style={styles.medicationLabel}>Dosage: </Text>{med.dosage}
                </Text>
                <Text style={styles.medicationDetails}>
                  <Text style={styles.medicationLabel}>Purpose: </Text>{med.purpose}
                </Text>
              </View>
            ))}
            
            <View style={styles.urgencyContainer}>
              <Ionicons name="time-outline" size={24} color="#ff4d4d" />
              <Text style={styles.urgencyText}>{analysisResult.urgency}</Text>
            </View>
            
            <View style={styles.actionButtonsContainer}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.primaryActionButton]}
                onPress={() => navigation.navigate('VetLocator')}
              >
                <Text style={styles.primaryActionButtonText}>Find Nearby Vets</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.secondaryActionButton]}
                onPress={() => setAnalysisResult(null)}
              >
                <Text style={styles.secondaryActionButtonText}>New Analysis</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1d3557',
  },
  tabContainer: {
    flexDirection: 'row',
    padding: 4,
    marginHorizontal: 16,
    backgroundColor: '#e9ecef',
    borderRadius: 12,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 10,
  },
  activeTab: {
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6c757d',
  },
  activeTabText: {
    color: '#1d3557',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1d3557',
    marginBottom: 12,
  },
  animalTypeContainer: {
    marginBottom: 24,
  },
  animalTypeContent: {
    paddingRight: 16,
  },
  animalTypeButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    marginRight: 12,
    borderRadius: 12,
    backgroundColor: '#ffffff',
    width: 90,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  selectedAnimalType: {
    backgroundColor: '#3a86ff',
  },
  animalTypeName: {
    marginTop: 8,
    fontSize: 14,
    color: '#495057',
  },
  selectedAnimalTypeName: {
    color: '#ffffff',
  },
  symptomsContainer: {
    marginBottom: 24,
  },
  symptomsInput: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#495057',
    borderWidth: 1,
    borderColor: '#dee2e6',
    textAlignVertical: 'top',
    marginBottom: 16,
    minHeight: 150,
  },
  tipsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1d3557',
    marginBottom: 8,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  bulletPoint: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#3a86ff',
    marginRight: 8,
  },
  tipText: {
    fontSize: 14,
    color: '#6c757d',
  },
  uploadContainer: {
    marginBottom: 24,
  },
  uploadBox: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderStyle: 'dashed',
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  uploadText: {
    fontSize: 14,
    color: '#6c757d',
    marginVertical: 12,
    textAlign: 'center',
  },
  uploadButton: {
    backgroundColor: '#e6f0ff',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  uploadButtonText: {
    color: '#3a86ff',
    fontWeight: '600',
  },
  analyzeButton: {
    backgroundColor: '#3a86ff',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 24,
  },
  disabledButton: {
    backgroundColor: '#adb5bd',
  },
  analyzeButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  resultContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1d3557',
    marginBottom: 8,
  },
  severityBadge: {
    backgroundColor: '#ffb703',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  severityText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  resultImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  resultDescription: {
    fontSize: 14,
    color: '#495057',
    lineHeight: 20,
    marginBottom: 16,
  },
  recommendationsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1d3557',
    marginBottom: 8,
    marginTop: 8,
  },
  recommendationItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  recommendationBullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#3a86ff',
    marginTop: 6,
    marginRight: 8,
  },
  recommendationText: {
    fontSize: 14,
    color: '#495057',
    flex: 1,
  },
  medicationItem: {
    backgroundColor: '#f1f3f5',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  medicationName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1d3557',
    marginBottom: 4,
  },
  medicationDetails: {
    fontSize: 13,
    color: '#495057',
    marginBottom: 2,
  },
  medicationLabel: {
    fontWeight: '500',
  },
  urgencyContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8d7da',
    padding: 12,
    borderRadius: 8,
    marginTop: 16,
    marginBottom: 16,
  },
  urgencyText: {
    color: '#721c24',
    fontSize: 14,
    marginLeft: 8,
    flex: 1,
  },
  actionButtonsContainer: {
    marginTop: 8,
  },
  actionButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  primaryActionButton: {
    backgroundColor: '#3a86ff',
  },
  primaryActionButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  secondaryActionButton: {
    backgroundColor: '#e9ecef',
  },
  secondaryActionButtonText: {
    color: '#495057',
    fontWeight: '600',
    fontSize: 16,
  },
});