import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Image, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

export default function VetLocatorScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState('list');
  const [searchQuery, setSearchQuery] = useState('');

  const vets = [
    {
      id: '1',
      name: 'City Pet Hospital',
      distance: '0.8 mi',
      rating: 4.8,
      reviewCount: 124,
      address: '123 Main St, San Francisco, CA',
      phone: '(415) 555-1234',
      hours: 'Open · Closes 8PM',
      image: 'https://api.a0.dev/assets/image?text=modern%20veterinary%20clinic%20reception&aspect=16:9',
      specialties: ['Dogs', 'Cats', 'Exotics'],
      emergency: true,
    },
    {
      id: '2',
      name: 'Animal Care Center',
      distance: '1.2 mi',
      rating: 4.6,
      reviewCount: 98,
      address: '456 Oak Ave, San Francisco, CA',
      phone: '(415) 555-5678',
      hours: 'Open · Closes 6PM',
      image: 'https://api.a0.dev/assets/image?text=veterinary%20clinic%20building%20exterior&aspect=16:9',
      specialties: ['Dogs', 'Cats', 'Birds'],
      emergency: false,
    },
    {
      id: '3',      name: 'Dr. Smith\'s Veterinary',
      distance: '2.3 mi',
      rating: 4.9,
      reviewCount: 210,
      address: '789 Pine St, San Francisco, CA',
      phone: '(415) 555-9012',
      hours: 'Open · Closes 9PM',
      image: 'https://api.a0.dev/assets/image?text=vet%20examining%20dog&aspect=16:9',
      specialties: ['Dogs', 'Cats', 'Rabbits', 'Reptiles'],
      emergency: true,
    },
    {
      id: '4',
      name: 'Bay Area Pet Clinic',
      distance: '3.1 mi',
      rating: 4.5,
      reviewCount: 87,
      address: '101 Market St, San Francisco, CA',
      phone: '(415) 555-3456',
      hours: 'Closed · Opens 8AM tomorrow',
      image: 'https://api.a0.dev/assets/image?text=pet%20clinic%20waiting%20room&aspect=16:9',
      specialties: ['Dogs', 'Cats'],
      emergency: false,
    },
  ];

  const filteredVets = vets.filter(vet => {
    const lowerCaseQuery = searchQuery.toLowerCase();
    return (
      vet.name.toLowerCase().includes(lowerCaseQuery) ||
      vet.address.toLowerCase().includes(lowerCaseQuery) ||
      vet.specialties.some(specialty => specialty.toLowerCase().includes(lowerCaseQuery))
    );
  });

  const renderVetItem = ({ item }) => (
    <View style={styles.vetCard}>
      <Image source={{ uri: item.image }} style={styles.vetImage} />
      
      <View style={styles.vetContent}>
        <View style={styles.vetHeader}>
          <Text style={styles.vetName}>{item.name}</Text>
          {item.emergency && (
            <View style={styles.emergencyBadge}>
              <Text style={styles.emergencyText}>24/7</Text>
            </View>
          )}
        </View>
        
        <View style={styles.vetDetails}>
          <View style={styles.vetDetailItem}>
            <Ionicons name="location" size={16} color="#6c757d" />
            <Text style={styles.vetDetailText}>{item.distance} · {item.address}</Text>
          </View>
          
          <View style={styles.vetDetailItem}>
            <Ionicons name="star" size={16} color="#ffb703" />
            <Text style={styles.vetDetailText}>
              {item.rating} ({item.reviewCount} reviews)
            </Text>
          </View>
          
          <View style={styles.vetDetailItem}>
            <Ionicons name="time" size={16} color={item.hours.includes('Open') ? '#09a129' : '#6c757d'} />
            <Text 
              style={[
                styles.vetDetailText, 
                { color: item.hours.includes('Open') ? '#09a129' : '#6c757d' }
              ]}
            >
              {item.hours}
            </Text>
          </View>
          
          <View style={styles.specialtiesContainer}>
            {item.specialties.map((specialty, index) => (
              <View key={index} style={styles.specialtyBadge}>
                <Text style={styles.specialtyText}>{specialty}</Text>
              </View>
            ))}
          </View>
        </View>
        
        <View style={styles.vetActions}>
          <TouchableOpacity style={styles.vetActionButton}>
            <Ionicons name="call" size={20} color="#3a86ff" />
            <Text style={styles.vetActionText}>Call</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.vetActionButton}>
            <Ionicons name="navigate" size={20} color="#3a86ff" />
            <Text style={styles.vetActionText}>Directions</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.vetActionButton}>
            <Ionicons name="bookmark-outline" size={20} color="#3a86ff" />
            <Text style={styles.vetActionText}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1d3557" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Find Veterinarians</Text>
        <TouchableOpacity>
          <Ionicons name="filter" size={24} color="#1d3557" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#6c757d" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name, location, or specialty"
          placeholderTextColor="#adb5bd"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery !== '' && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <Ionicons name="close-circle" size={20} color="#6c757d" />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'list' && styles.activeTab]}
          onPress={() => setActiveTab('list')}
        >
          <Ionicons 
            name="list" 
            size={18} 
            color={activeTab === 'list' ? '#3a86ff' : '#6c757d'} 
            style={styles.tabIcon} 
          />
          <Text 
            style={[
              styles.tabText, 
              activeTab === 'list' && styles.activeTabText
            ]}
          >
            List
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'map' && styles.activeTab]}
          onPress={() => setActiveTab('map')}
        >
          <Ionicons 
            name="map" 
            size={18} 
            color={activeTab === 'map' ? '#3a86ff' : '#6c757d'} 
            style={styles.tabIcon} 
          />
          <Text 
            style={[
              styles.tabText, 
              activeTab === 'map' && styles.activeTabText
            ]}
          >
            Map
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'list' ? (
        <FlatList
          data={filteredVets}
          renderItem={renderVetItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="search" size={48} color="#adb5bd" />
              <Text style={styles.emptyText}>No veterinarians found</Text>
              <Text style={styles.emptySubtext}>Try adjusting your search</Text>
            </View>
          }
        />
      ) : (
        <View style={styles.mapContainer}>
          <Image 
            source={{ uri: 'https://api.a0.dev/assets/image?text=map%20with%20veterinary%20locations%20marked&aspect=1:1' }} 
            style={styles.mapImage} 
          />
          <View style={styles.mapOverlay}>
            <Text style={styles.mapText}>Map View</Text>
            <Text style={styles.mapSubtext}>This would display an interactive map with vet locations</Text>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1d3557',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingHorizontal: 12,
    marginHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#dee2e6',
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#495057',
  },
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginVertical: 16,
    backgroundColor: '#e9ecef',
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 12,
    borderRadius: 10,
  },
  activeTab: {
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabIcon: {
    marginRight: 6,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6c757d',
  },
  activeTabText: {
    color: '#3a86ff',
    fontWeight: '600',
  },
  listContainer: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  vetCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  vetImage: {
    width: '100%',
    height: 150,
  },
  vetContent: {
    padding: 16,
  },
  vetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  vetName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1d3557',
    flex: 1,
  },
  emergencyBadge: {
    backgroundColor: '#ff4d4d',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  emergencyText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  vetDetails: {
    marginBottom: 12,
  },
  vetDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  vetDetailText: {
    fontSize: 14,
    color: '#6c757d',
    marginLeft: 6,
  },
  specialtiesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  specialtyBadge: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginRight: 6,
    marginBottom: 6,
  },
  specialtyText: {
    color: '#3a86ff',
    fontSize: 12,
    fontWeight: '500',
  },
  vetActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e9ecef',
    paddingTop: 12,
    marginTop: 4,
  },
  vetActionButton: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    paddingVertical: 8,
  },
  vetActionText: {
    color: '#3a86ff',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#495057',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#6c757d',
    marginTop: 4,
  },
  mapContainer: {
    flex: 1,
    margin: 16,
    borderRadius: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  mapImage: {
    width: '100%',
    height: '100%',
  },
  mapOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  mapText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  mapSubtext: {
    fontSize: 14,
    color: '#ffffff',
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 24,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
});