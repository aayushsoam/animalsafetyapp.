import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';

export default function CameraScreen({ navigation }) {
  const [facing, setFacing] = useState<CameraType>('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);

  if (!permission) {
    // Camera permissions are still loading
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#3a86ff" />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.permissionContainer}>
        <Ionicons name="camera-outline" size={64} color="#3a86ff" />
        <Text style={styles.permissionTitle}>Camera Access Needed</Text>
        <Text style={styles.permissionText}>
          We need camera access to scan animal injuries and provide emergency guidance.
        </Text>
        <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
          <Text style={styles.permissionButtonText}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const toggleCamera = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const handleCapture = async () => {
    setAnalyzing(true);
    // Simulate image capture and analysis
    setTimeout(() => {
      setCapturedImage('https://api.a0.dev/assets/image?text=injured%20dog%20paw%20closeup&aspect=1:1');
      setAnalysisResult({
        injury: 'Paw Laceration',
        confidence: 92,
        severity: 'Moderate',
        recommendations: [
          'Clean wound with saline solution',
          'Apply pressure to stop bleeding',
          'Keep the area bandaged',
          'Seek veterinary care within 24 hours'
        ]
      });
      setAnalyzing(false);
    }, 2000);
  };

  const resetCamera = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1d3557" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Injury Scanner</Text>
        <View style={{ width: 24 }} />
      </View>

      {!capturedImage ? (
        <>
          <View style={styles.cameraContainer}>
            <CameraView 
              style={styles.camera} 
              facing={facing}
            >
              <View style={styles.overlay}>
                <View style={styles.scanFrame} />
              </View>
            </CameraView>
          </View>

          <View style={styles.instructions}>
            <Text style={styles.instructionTitle}>Scan Animal Injury</Text>
            <Text style={styles.instructionText}>
              Position the camera so the injury is clearly visible within the frame. 
              Hold steady for best results.
            </Text>
          </View>

          <View style={styles.controls}>
            <TouchableOpacity style={styles.controlButton} onPress={toggleCamera}>
              <Ionicons name="camera-reverse-outline" size={24} color="#1d3557" />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.captureButton} 
              onPress={handleCapture}
            >
              <View style={styles.captureButtonInner} />
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.controlButton}>
              <Ionicons name="flash-outline" size={24} color="#1d3557" />
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={styles.analysisContainer}>
          <Image source={{ uri: capturedImage }} style={styles.capturedImage} />
          
          {analyzing ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#3a86ff" />
              <Text style={styles.loadingText}>Analyzing injury...</Text>
            </View>
          ) : (
            <View style={styles.resultContainer}>
              <View style={styles.resultHeader}>
                <Text style={styles.resultTitle}>{analysisResult.injury}</Text>
                <View style={styles.confidenceBadge}>
                  <Text style={styles.confidenceText}>{analysisResult.confidence}% match</Text>
                </View>
              </View>
              
              <View style={styles.severityContainer}>
                <Text style={styles.severityLabel}>Severity:</Text>
                <View style={[
                  styles.severityBadge, 
                  { backgroundColor: analysisResult.severity === 'High' ? '#ff4d4d' : '#ffb703' }
                ]}>
                  <Text style={styles.severityText}>{analysisResult.severity}</Text>
                </View>
              </View>
              
              <Text style={styles.recommendationTitle}>Recommendations:</Text>
              {analysisResult.recommendations.map((rec, index) => (
                <View key={index} style={styles.recommendationItem}>
                  <View style={styles.bulletPoint} />
                  <Text style={styles.recommendationText}>{rec}</Text>
                </View>
              ))}
              
              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={[styles.actionButton, styles.primaryButton]}
                  onPress={() => navigation.navigate('VetLocator')}
                >
                  <Text style={styles.primaryButtonText}>Find Nearby Vets</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[styles.actionButton, styles.secondaryButton]}
                  onPress={resetCamera}
                >
                  <Text style={styles.secondaryButtonText}>Scan Again</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1d3557',
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  permissionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1d3557',
    marginTop: 16,
    marginBottom: 8,
  },
  permissionText: {
    fontSize: 16,
    color: '#6c757d',
    textAlign: 'center',
    marginBottom: 24,
  },
  permissionButton: {
    backgroundColor: '#3a86ff',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 12,
  },
  permissionButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cameraContainer: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: 24,
    margin: 16,
  },
  camera: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanFrame: {
    width: 250,
    height: 250,
    borderWidth: 2,
    borderColor: '#3a86ff',
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  instructions: {
    padding: 16,
  },
  instructionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1d3557',
    marginBottom: 8,
  },
  instructionText: {
    fontSize: 14,
    color: '#6c757d',
    lineHeight: 20,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#e9ecef',
    justifyContent: 'center',
    alignItems: 'center',
  },
  captureButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#3a86ff',
  },
  captureButtonInner: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#3a86ff',
  },
  analysisContainer: {
    flex: 1,
    margin: 16,
    backgroundColor: '#ffffff',
    borderRadius: 24,
    overflow: 'hidden',
  },
  capturedImage: {
    width: '100%',
    height: 240,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#6c757d',
  },
  resultContainer: {
    flex: 1,
    padding: 16,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  resultTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1d3557',
  },
  confidenceBadge: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  confidenceText: {
    color: '#3a86ff',
    fontWeight: '600',
    fontSize: 12,
  },
  severityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  severityLabel: {
    fontSize: 16,
    color: '#495057',
    marginRight: 8,
  },
  severityBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#ffb703',
  },
  severityText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 12,
  },
  recommendationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1d3557',
    marginBottom: 12,
  },
  recommendationItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  bulletPoint: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#3a86ff',
    marginTop: 6,
    marginRight: 8,
  },
  recommendationText: {
    fontSize: 14,
    color: '#495057',
    flex: 1,
  },
  actionButtons: {
    marginTop: 24,
  },
  actionButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  primaryButton: {
    backgroundColor: '#3a86ff',
  },
  primaryButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  secondaryButton: {
    backgroundColor: '#e9ecef',
  },
  secondaryButtonText: {
    color: '#495057',
    fontWeight: '600',
    fontSize: 16,
  },
});