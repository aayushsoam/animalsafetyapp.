import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ImageBackground } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import EmergencyTipCard from '../components/EmergencyTipCard';

export default function HomeScreen({ navigation }) {
  const emergencyTips = [
    {
      id: 1,
      title: 'Bleeding',
      description: 'Apply direct pressure with clean cloth. Elevate injured area if possible.',
      icon: 'water-alert',
    },
    {
      id: 2,
      title: 'Broken Bone',
      description: 'Immobilize the area. Do not attempt to straighten the limb.',
      icon: 'bone',
    },
    {
      id: 3,
      title: 'Poisoning',
      description: 'Keep packaging of toxin. Call vet immediately, don\'t induce vomiting.',
      icon: 'biohazard',
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Animal Safety</Text>
          <TouchableOpacity style={styles.profileButton}>
            <Ionicons name="person-circle-outline" size={40} color="#3a86ff" />
          </TouchableOpacity>
        </View>

        <View style={styles.heroSection}>
          <ImageBackground
            source={{ uri: 'https://api.a0.dev/assets/image?text=veterinarian%20helping%20injured%20dog&aspect=16:9' }}
            style={styles.heroBg}
            imageStyle={styles.heroBgImage}
          >
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>Emergency Animal Care</Text>
              <Text style={styles.heroSubtitle}>Scan, Analyze, and Find Help</Text>
              <TouchableOpacity 
                style={styles.scanButton}
                onPress={() => navigation.navigate('Camera')}
              >
                <Ionicons name="camera" size={22} color="#fff" />
                <Text style={styles.scanButtonText}>Scan Injury</Text>
              </TouchableOpacity>
            </View>
          </ImageBackground>
        </View>

        <View style={styles.quickActions}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionButtons}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => navigation.navigate('InjuryAnalysis')}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#ffadad' }]}>
                <Ionicons name="medkit" size={24} color="#ff4d4d" />
              </View>
              <Text style={styles.actionText}>Injury Analysis</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => navigation.navigate('VetLocator')}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#adf7b6' }]}>
                <Ionicons name="location" size={24} color="#09a129" />
              </View>
              <Text style={styles.actionText}>Find Vets</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton}>
              <View style={[styles.actionIcon, { backgroundColor: '#cbc3e3' }]}>
                <Ionicons name="call" size={24} color="#6a4c93" />
              </View>
              <Text style={styles.actionText}>Emergency Call</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.recentSection}>
          <Text style={styles.sectionTitle}>Recent Emergencies</Text>
          <View style={styles.recentCard}>
            <Image 
              source={{ uri: 'https://api.a0.dev/assets/image?text=injured%20cat%20paw&aspect=1:1' }} 
              style={styles.recentImage} 
            />
            <View style={styles.recentInfo}>
              <Text style={styles.recentTitle}>Cat Paw Injury</Text>
              <Text style={styles.recentDate}>Yesterday, 2:30 PM</Text>
              <View style={styles.severityBadge}>
                <Text style={styles.severityText}>Moderate</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Emergency First Aid Tips</Text>
          {emergencyTips.map(tip => (
            <EmergencyTipCard key={tip.id} tip={tip} />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1d3557',
  },
  profileButton: {
    padding: 4,
  },
  heroSection: {
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 16,
    overflow: 'hidden',
    height: 180,
  },
  heroBg: {
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
  },
  heroBgImage: {
    borderRadius: 16,
  },
  heroContent: {
    backgroundColor: 'rgba(0,0,0,0.4)',
    padding: 16,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  heroSubtitle: {
    fontSize: 14,
    color: '#f8f9fa',
    marginBottom: 12,
  },
  scanButton: {
    backgroundColor: '#3a86ff',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
  },
  scanButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    marginLeft: 8,
  },
  quickActions: {
    marginTop: 16,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1d3557',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    alignItems: 'center',
    width: '30%',
  },
  actionIcon: {
    width: 60,
    height: 60,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#495057',
    textAlign: 'center',
  },
  recentSection: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  recentCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  recentImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  recentInfo: {
    marginLeft: 12,
    justifyContent: 'center',
    flex: 1,
  },
  recentTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1d3557',
  },
  recentDate: {
    fontSize: 12,
    color: '#6c757d',
    marginTop: 4,
  },
  severityBadge: {
    backgroundColor: '#ffb703',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  severityText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  tipsSection: {
    marginTop: 24,
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
});